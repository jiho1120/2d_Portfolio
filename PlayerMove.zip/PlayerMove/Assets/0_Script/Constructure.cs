using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Constructure
{
    public struct Stat
    {
        public float HP;
        public float MaxHP;
        public float Att;
        public float Skill;

        public Stat(float hp, float att, float skill)
        {
            this.HP = hp;
            this.MaxHP = hp;
            this.Att = att;
            this.Skill = skill;
        }
    }
}
